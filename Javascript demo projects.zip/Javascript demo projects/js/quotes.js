const quotes = [
  {
    quote: "Change the world one sequins at a time",
    author: "Lady Gaga",
  },
  {
    quote: "If you don't have any shadows, you're not standing in the light",
    author: "Lady Gaga",
  },
  {
    quote: "They can't scare me if I scare them first",
    author: "Lady Gaga",
  },
  {
    quote:
      "Don't allow people to dim your shine because they are blinded. Tell them to put on some sunglasses.",
    author: "Lady Gaga",
  },
  {
    quote:
      "Don't you ever let a soul in the world tell you that you can't be exactly who you are",
    author: "Lady Gaga",
  },
  {
    quote: "My beautiful vagina and I are very offended by that!",
    author: "Lady Gaga",
  },
  {
    quote: "You may say I lost everything, but I still had... my bedazzler.",
    author: "Lady Gaga",
  },
  {
    quote: "Once you kill a cow, you gotta make a burger.",
    author: "Lady Gaga",
  },
  {
    quote:
      "Trust is like a mirror. You can fix it if it's broken, but you can still see the crack in that mfer's reflection.",
    author: "Lady Gaga",
  },
  {
    quote: "You can be smart, and in your underwear.",
    author: "Lady Gaga",
  },
  {
    quote:
      "Never be afraid to be kicked in the teeth. Let the blood and bruises define your legacy.",
    author: "Lady Gaga",
  },
  {
    quote: "Live for what you create, and die protecting it.",
    author: "Lady Gaga",
  },
  {
    quote: "Love is like a brick. You can build a house or sink a dead body.",
    author: "Lady Gaga",
  },
  {
    quote: "Don't be a drag, just be a queen!",
    author: "Lady Gaga",
  },
];
